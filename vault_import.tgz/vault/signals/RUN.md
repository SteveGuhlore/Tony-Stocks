---
ticker: RUN
tags: [signal]
status: entry_not_triggered
first_seen: 2026-05-18
days_active: 7
---

# RUN

**Status:** partial_move
**Days Active:** 5

## Signal History
| Date | Setup | Score | Status |
|------|-------|-------|--------|
| [[2026-05-18]] | Speculative Watchlist | 64.55 | partial_move |
| [[2026-05-19]] | Speculative Watchlist | 64.55 | partial_move |
| [[2026-05-20]] | Speculative Watchlist | 62.63 | partial_move |
| [[2026-05-21]] | Speculative Watchlist | 63.87 | partial_move |
| [[2026-05-22]] | Speculative Watchlist | 72.82 | insufficient_future_data |
| [[2026-05-26]] | Speculative Watchlist | 72.82 | insufficient_future_data |
| [[2026-05-29]] | Speculative Watchlist | 72.82 | insufficient_future_data |
| [[2026-06-02]] | Speculative Watchlist | 72.82 | partial_move |
| [[2026-06-03]] | Speculative Watchlist | 74.28 | insufficient_future_data |
| [[2026-06-04]] | Speculative Watchlist | 77.42 | active |
| [[2026-06-05]] | Speculative Watchlist | 79.63 | entry_not_triggered |
| [[2026-06-06]] | Speculative Watchlist | 79.63 | entry_not_triggered |

## Entry Plan
*Populated when entry triggered.*

## Outcome
*Populated on close. Forward-compatible: will hold fill price, order ID, broker confirmation in Phase 4-5.*

## Notes

---
[[index]]