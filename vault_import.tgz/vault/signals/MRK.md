---
ticker: MRK
tags: [signal]
status: active
first_seen: 2026-06-05
days_active: 3
---

# MRK

**Status:** active
**Days Active:** 2

## Signal History
| Date | Setup | Score | Status |
|------|-------|-------|--------|
| [[2026-06-05]] | Momentum Continuation | 72.98 | active |
| [[2026-06-06]] | Momentum Continuation | 78.38 | active |

## Entry Plan
*Populated when entry triggered.*

## Outcome
*Populated on close. Forward-compatible: will hold fill price, order ID, broker confirmation in Phase 4-5.*

## Notes

---
[[index]]