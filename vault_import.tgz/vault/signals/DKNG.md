---
ticker: DKNG
tags: [signal]
status: active
first_seen: 2026-05-18
days_active: 8
---

# DKNG

**Status:** partial_move
**Days Active:** 5

## Signal History
| Date | Setup | Score | Status |
|------|-------|-------|--------|
| [[2026-05-18]] | Speculative Watchlist | 84.26 | partial_move |
| [[2026-05-19]] | Speculative Watchlist | 84.18 | partial_move |
| [[2026-05-20]] | Speculative Watchlist | 84.15 | partial_move |
| [[2026-05-21]] | Speculative Watchlist | 84.0 | partial_move |
| [[2026-05-22]] | Speculative Watchlist | 74.55 | insufficient_future_data |
| [[2026-05-26]] | Speculative Watchlist | 74.55 | insufficient_future_data |
| [[2026-05-29]] | Speculative Watchlist | 74.55 | insufficient_future_data |
| [[2026-06-02]] | Speculative Watchlist | 74.55 | partial_move |
| [[2026-06-03]] | Breakout Watch | 62.49 | insufficient_future_data |
| [[2026-06-04]] | Speculative Watchlist | 79.25 | active |
| [[2026-06-05]] | Speculative Watchlist | 77.72 | active |
| [[2026-06-06]] | Speculative Watchlist | 77.72 | active |

## Entry Plan
*Populated when entry triggered.*

## Outcome
*Populated on close. Forward-compatible: will hold fill price, order ID, broker confirmation in Phase 4-5.*

## Notes

---
[[index]]