---
ticker: ON
tags: [signal]
status: insufficient_future_data
first_seen: 2026-06-05
days_active: 2
---

# ON

**Status:** insufficient_future_data
**Days Active:** 1

## Signal History
| Date | Setup | Score | Status |
|------|-------|-------|--------|
| [[2026-06-05]] | Momentum Continuation | 79.54 | insufficient_future_data |
| [[2026-06-06]] | Pullback Watch | 92.29 | insufficient_future_data |

## Entry Plan
*Populated when entry triggered.*

## Outcome
*Populated on close. Forward-compatible: will hold fill price, order ID, broker confirmation in Phase 4-5.*

## Notes

---
[[index]]