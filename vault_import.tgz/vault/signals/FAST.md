---
ticker: FAST
tags: [signal]
status: active
first_seen: 2026-06-03
days_active: 4
---

# FAST

**Status:** insufficient_future_data
**Days Active:** 1

## Signal History
| Date | Setup | Score | Status |
|------|-------|-------|--------|
| [[2026-06-03]] | Momentum Continuation | 72.47 | insufficient_future_data |
| [[2026-06-04]] | Momentum Continuation | 74.55 | active |
| [[2026-06-05]] | Momentum Continuation | 74.64 | active |
| [[2026-06-06]] | Momentum Continuation | 80.76 | active |

## Entry Plan
*Populated when entry triggered.*

## Outcome
*Populated on close. Forward-compatible: will hold fill price, order ID, broker confirmation in Phase 4-5.*

## Notes

---
[[index]]