---
ticker: CCL
tags: [signal]
status: active
first_seen: 2026-06-03
days_active: 3
---

# CCL

**Status:** insufficient_future_data
**Days Active:** 1

## Signal History
| Date | Setup | Score | Status |
|------|-------|-------|--------|
| [[2026-06-03]] | Breakout Watch | 79.98 | insufficient_future_data |
| [[2026-06-04]] | Breakout Watch | 75.26 | active |
| [[2026-06-05]] | Breakout Watch | 72.21 | active |
| [[2026-06-06]] | Breakout Watch | 69.51 | active |

## Entry Plan
*Populated when entry triggered.*

## Outcome
*Populated on close. Forward-compatible: will hold fill price, order ID, broker confirmation in Phase 4-5.*

## Notes

---
[[index]]