---
ticker: PATH
tags: [signal]
status: active
first_seen: 2026-05-19
days_active: 6
---

# PATH

**Status:** partial_move
**Days Active:** 2

## Signal History
| Date | Setup | Score | Status |
|------|-------|-------|--------|
| [[2026-05-19]] | Breakout Watch | 63.54 | partial_move |
| [[2026-05-22]] | Breakout Watch | 73.27 | insufficient_future_data |
| [[2026-05-26]] | Breakout Watch | 73.27 | insufficient_future_data |
| [[2026-05-29]] | Breakout Watch | 73.27 | insufficient_future_data |
| [[2026-06-02]] | Breakout Watch | 73.27 | partial_move |
| [[2026-06-03]] | Momentum Continuation | 79.17 | insufficient_future_data |
| [[2026-06-04]] | Momentum Continuation | 79.13 | active |
| [[2026-06-05]] | Momentum Continuation | 79.49 | active |
| [[2026-06-06]] | Pullback Watch | 73.42 | active |

## Entry Plan
*Populated when entry triggered.*

## Outcome
*Populated on close. Forward-compatible: will hold fill price, order ID, broker confirmation in Phase 4-5.*

## Notes

---
[[index]]