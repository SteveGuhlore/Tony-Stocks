---
ticker: HOOD
tags: [signal]
status: active
first_seen: 2026-05-17
days_active: 6
---

# HOOD

**Status:** entry_not_triggered
**Days Active:** 2

## Signal History
| Date | Setup | Score | Status |
|------|-------|-------|--------|
| [[2026-05-17]] | Breakout Watch | 97.98 | entry_not_triggered |
| [[2026-05-18]] | Breakout Watch | 97.98 | entry_not_triggered |
| [[2026-05-26]] | Breakout Watch | 97.98 | entry_not_triggered |
| [[2026-05-29]] | Breakout Watch | 97.98 | entry_not_triggered |
| [[2026-06-02]] | Breakout Watch | 97.98 | entry_not_triggered |
| [[2026-06-03]] | Momentum Continuation | 79.62 | insufficient_future_data |
| [[2026-06-04]] | Momentum Continuation | 79.45 | active |
| [[2026-06-05]] | Momentum Continuation | 79.66 | active |
| [[2026-06-06]] | Pullback Watch | 77.34 | active |

## Entry Plan
*Populated when entry triggered.*

## Outcome
*Populated on close. Forward-compatible: will hold fill price, order ID, broker confirmation in Phase 4-5.*

## Notes

---
[[index]]