---
ticker: WULF
tags: [signal]
status: insufficient_future_data
first_seen: 2026-06-05
days_active: 2
---

# WULF

**Status:** insufficient_future_data
**Days Active:** 2

## Signal History
| Date | Setup | Score | Status |
|------|-------|-------|--------|
| [[2026-06-05]] | Speculative Watchlist | 66.77 | insufficient_future_data |
| [[2026-06-06]] | Speculative Watchlist | 68.74 | insufficient_future_data |

## Entry Plan
*Populated when entry triggered.*

## Outcome
*Populated on close. Forward-compatible: will hold fill price, order ID, broker confirmation in Phase 4-5.*

## Notes

---
[[index]]