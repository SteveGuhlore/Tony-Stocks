---
ticker: BAC
tags: [signal]
status: active
first_seen: 2026-05-22
days_active: 5
---

# BAC

**Status:** insufficient_future_data
**Days Active:** 1

## Signal History
| Date | Setup | Score | Status |
|------|-------|-------|--------|
| [[2026-05-22]] | Breakout Watch | 75.19 | insufficient_future_data |
| [[2026-05-26]] | Breakout Watch | 75.19 | insufficient_future_data |
| [[2026-05-29]] | Breakout Watch | 75.19 | insufficient_future_data |
| [[2026-06-02]] | Breakout Watch | 75.19 | partial_move |
| [[2026-06-03]] | Breakout Watch | 64.67 | insufficient_future_data |
| [[2026-06-04]] | Breakout Watch | 64.2 | active |
| [[2026-06-05]] | Breakout Watch | 72.0 | active |
| [[2026-06-06]] | Breakout Watch | 75.09 | active |

## Entry Plan
*Populated when entry triggered.*

## Outcome
*Populated on close. Forward-compatible: will hold fill price, order ID, broker confirmation in Phase 4-5.*

## Notes

---
[[index]]