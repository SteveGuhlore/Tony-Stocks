---
ticker: GLW
tags: [signal]
status: active
first_seen: 2026-06-05
days_active: 2
---

# GLW

**Status:** active
**Days Active:** 1

## Signal History
| Date | Setup | Score | Status |
|------|-------|-------|--------|
| [[2026-06-05]] | Breakout Watch | 89.97 | active |
| [[2026-06-06]] | Pullback Watch | 63.63 | active |

## Entry Plan
*Populated when entry triggered.*

## Outcome
*Populated on close. Forward-compatible: will hold fill price, order ID, broker confirmation in Phase 4-5.*

## Notes

---
[[index]]