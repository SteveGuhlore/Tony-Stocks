---
ticker: DBX
tags: [signal]
status: active
first_seen: 2026-06-05
days_active: 2
---

# DBX

**Status:** active
**Days Active:** 1

## Signal History
| Date | Setup | Score | Status |
|------|-------|-------|--------|
| [[2026-06-05]] | Breakout Watch | 81.88 | active |
| [[2026-06-06]] | Breakout Watch | 82.13 | active |

## Entry Plan
*Populated when entry triggered.*

## Outcome
*Populated on close. Forward-compatible: will hold fill price, order ID, broker confirmation in Phase 4-5.*

## Notes

---
[[index]]