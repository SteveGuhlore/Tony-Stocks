---
ticker: DXCM
tags: [signal]
status: active
first_seen: 2026-05-18
days_active: 6
---

# DXCM

**Status:** target_hit
**Days Active:** 2

## Signal History
| Date | Setup | Score | Status |
|------|-------|-------|--------|
| [[2026-05-18]] | Momentum Continuation | 71.76 | target_hit |
| [[2026-05-19]] | Momentum Continuation | 67.41 | target_hit |
| [[2026-05-26]] | Momentum Continuation | 67.41 | target_hit |
| [[2026-05-29]] | Momentum Continuation | 67.41 | target_hit |
| [[2026-06-02]] | Momentum Continuation | 67.41 | target_hit |
| [[2026-06-03]] | Momentum Continuation | 67.41 | target_hit |
| [[2026-06-04]] | Breakout Watch | 81.91 | active |
| [[2026-06-05]] | Breakout Watch | 81.85 | active |
| [[2026-06-06]] | Breakout Watch | 82.16 | active |

## Entry Plan
*Populated when entry triggered.*

## Outcome
*Populated on close. Forward-compatible: will hold fill price, order ID, broker confirmation in Phase 4-5.*

## Notes

---
[[index]]