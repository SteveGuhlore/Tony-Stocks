---
ticker: JOBY
tags: [signal]
status: entry_not_triggered
first_seen: 2026-05-18
days_active: 5
---

# JOBY

**Status:** partial_move
**Days Active:** 3

## Signal History
| Date | Setup | Score | Status |
|------|-------|-------|--------|
| [[2026-05-18]] | Speculative Watchlist | 69.77 | partial_move |
| [[2026-05-19]] | Speculative Watchlist | 76.23 | partial_move |
| [[2026-05-21]] | Speculative Watchlist | 70.05 | partial_move |
| [[2026-05-26]] | Speculative Watchlist | 70.05 | partial_move |
| [[2026-05-29]] | Speculative Watchlist | 70.05 | partial_move |
| [[2026-06-02]] | Speculative Watchlist | 70.05 | partial_move |
| [[2026-06-03]] | Speculative Watchlist | 77.07 | insufficient_future_data |
| [[2026-06-04]] | Speculative Watchlist | 69.06 | insufficient_future_data |
| [[2026-06-05]] | Speculative Watchlist | 70.57 | entry_not_triggered |
| [[2026-06-06]] | Speculative Watchlist | 70.57 | entry_not_triggered |

## Entry Plan
*Populated when entry triggered.*

## Outcome
*Populated on close. Forward-compatible: will hold fill price, order ID, broker confirmation in Phase 4-5.*

## Notes

---
[[index]]