---
ticker: MARA
tags: [signal]
status: entry_not_triggered
first_seen: 2026-05-18
days_active: 6
---

# MARA

**Status:** partial_move
**Days Active:** 4

## Signal History
| Date | Setup | Score | Status |
|------|-------|-------|--------|
| [[2026-05-18]] | Speculative Watchlist | 73.98 | partial_move |
| [[2026-05-19]] | Speculative Watchlist | 65.58 | partial_move |
| [[2026-05-20]] | Speculative Watchlist | 80.61 | partial_move |
| [[2026-05-21]] | Speculative Watchlist | 79.63 | partial_move |
| [[2026-05-26]] | Speculative Watchlist | 79.63 | partial_move |
| [[2026-05-29]] | Speculative Watchlist | 79.63 | partial_move |
| [[2026-06-02]] | Speculative Watchlist | 79.63 | partial_move |
| [[2026-06-03]] | Speculative Watchlist | 81.84 | insufficient_future_data |
| [[2026-06-04]] | Speculative Watchlist | 69.65 | insufficient_future_data |
| [[2026-06-05]] | Speculative Watchlist | 69.44 | active |
| [[2026-06-06]] | Speculative Watchlist | 69.44 | entry_not_triggered |

## Entry Plan
*Populated when entry triggered.*

## Outcome
*Populated on close. Forward-compatible: will hold fill price, order ID, broker confirmation in Phase 4-5.*

## Notes

---
[[index]]