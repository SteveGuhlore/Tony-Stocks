---
ticker: LUV
tags: [signal]
status: insufficient_future_data
first_seen: 2026-06-05
days_active: 1
---

# LUV

**Status:** insufficient_future_data
**Days Active:** 1

## Signal History
| Date | Setup | Score | Status |
|------|-------|-------|--------|
| [[2026-06-05]] | Breakout Watch | 72.62 | insufficient_future_data |
| [[2026-06-06]] | Breakout Watch | 72.62 | insufficient_future_data |

## Entry Plan
*Populated when entry triggered.*

## Outcome
*Populated on close. Forward-compatible: will hold fill price, order ID, broker confirmation in Phase 4-5.*

## Notes

---
[[index]]