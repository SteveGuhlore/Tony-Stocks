---
ticker: RIOT
tags: [signal]
status: insufficient_future_data
first_seen: 2026-05-19
days_active: 3
---

# RIOT

**Status:** partial_move
**Days Active:** 1

## Signal History
| Date | Setup | Score | Status |
|------|-------|-------|--------|
| [[2026-05-19]] | Speculative Watchlist | 70.4 | partial_move |
| [[2026-05-26]] | Speculative Watchlist | 70.4 | partial_move |
| [[2026-05-29]] | Speculative Watchlist | 70.4 | partial_move |
| [[2026-06-02]] | Speculative Watchlist | 70.4 | target_hit |
| [[2026-06-03]] | Speculative Watchlist | 70.4 | target_hit |
| [[2026-06-04]] | Speculative Watchlist | 82.63 | insufficient_future_data |
| [[2026-06-05]] | Speculative Watchlist | 67.1 | insufficient_future_data |
| [[2026-06-06]] | Speculative Watchlist | 67.1 | insufficient_future_data |

## Entry Plan
*Populated when entry triggered.*

## Outcome
*Populated on close. Forward-compatible: will hold fill price, order ID, broker confirmation in Phase 4-5.*

## Notes

---
[[index]]