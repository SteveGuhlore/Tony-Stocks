---
ticker: MS
tags: [signal]
status: active
first_seen: 2026-06-03
days_active: 2
---

# MS

**Status:** insufficient_future_data
**Days Active:** 1

## Signal History
| Date | Setup | Score | Status |
|------|-------|-------|--------|
| [[2026-06-03]] | Breakout Watch | 84.09 | insufficient_future_data |
| [[2026-06-04]] | Breakout Watch | 84.22 | insufficient_future_data |
| [[2026-06-05]] | Breakout Watch | 84.12 | active |
| [[2026-06-06]] | Breakout Watch | 84.12 | active |

## Entry Plan
*Populated when entry triggered.*

## Outcome
*Populated on close. Forward-compatible: will hold fill price, order ID, broker confirmation in Phase 4-5.*

## Notes

---
[[index]]