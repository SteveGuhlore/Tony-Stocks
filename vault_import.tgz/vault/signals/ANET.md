---
ticker: ANET
tags: [signal]
status: active
first_seen: 2026-05-22
days_active: 3
---

# ANET

**Status:** insufficient_future_data
**Days Active:** 1

## Signal History
| Date | Setup | Score | Status |
|------|-------|-------|--------|
| [[2026-05-22]] | Pullback Watch | 72.73 | insufficient_future_data |
| [[2026-05-26]] | Pullback Watch | 72.73 | insufficient_future_data |
| [[2026-05-29]] | Pullback Watch | 72.73 | insufficient_future_data |
| [[2026-06-02]] | Pullback Watch | 72.73 | partial_move |
| [[2026-06-03]] | Pullback Watch | 72.73 | partial_move |
| [[2026-06-04]] | Momentum Continuation | 71.67 | insufficient_future_data |
| [[2026-06-05]] | Momentum Continuation | 71.57 | active |
| [[2026-06-06]] | Pullback Watch | 86.05 | active |

## Entry Plan
*Populated when entry triggered.*

## Outcome
*Populated on close. Forward-compatible: will hold fill price, order ID, broker confirmation in Phase 4-5.*

## Notes

---
[[index]]