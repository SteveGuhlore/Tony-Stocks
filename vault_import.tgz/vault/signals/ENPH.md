---
ticker: ENPH
tags: [signal]
status: entry_not_triggered
first_seen: 2026-05-17
days_active: 2
---

# ENPH

**Status:** entry_not_triggered
**Days Active:** 2

## Signal History
| Date | Setup | Score | Status |
|------|-------|-------|--------|
| [[2026-05-17]] | Breakout Watch | 95.36 | entry_not_triggered |
| [[2026-05-18]] | Breakout Watch | 95.36 | entry_not_triggered |
| [[2026-05-26]] | Breakout Watch | 95.36 | entry_not_triggered |
| [[2026-05-29]] | Breakout Watch | 95.36 | entry_not_triggered |
| [[2026-06-02]] | Breakout Watch | 95.36 | entry_not_triggered |
| [[2026-06-03]] | Breakout Watch | 95.36 | entry_not_triggered |

## Entry Plan
*Populated when entry triggered.*

## Outcome
*Populated on close. Forward-compatible: will hold fill price, order ID, broker confirmation in Phase 4-5.*

## Notes

---
[[index]]