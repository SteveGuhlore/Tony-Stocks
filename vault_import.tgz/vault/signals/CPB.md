---
ticker: CPB
tags: [signal]
status: insufficient_future_data
first_seen: 2026-06-05
days_active: 2
---

# CPB

**Status:** insufficient_future_data
**Days Active:** 1

## Signal History
| Date | Setup | Score | Status |
|------|-------|-------|--------|
| [[2026-06-05]] | Breakout Watch | 82.77 | insufficient_future_data |
| [[2026-06-06]] | Breakout Watch | 84.95 | insufficient_future_data |

## Entry Plan
*Populated when entry triggered.*

## Outcome
*Populated on close. Forward-compatible: will hold fill price, order ID, broker confirmation in Phase 4-5.*

## Notes

---
[[index]]