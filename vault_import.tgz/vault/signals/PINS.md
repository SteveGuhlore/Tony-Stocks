---
ticker: PINS
tags: [signal]
status: active
first_seen: 2026-05-18
days_active: 6
---

# PINS

**Status:** entry_not_triggered
**Days Active:** 1

## Signal History
| Date | Setup | Score | Status |
|------|-------|-------|--------|
| [[2026-05-18]] | Breakout Watch | 91.09 | entry_not_triggered |
| [[2026-05-26]] | Breakout Watch | 91.09 | entry_not_triggered |
| [[2026-05-29]] | Breakout Watch | 91.09 | entry_not_triggered |
| [[2026-06-02]] | Pullback Watch | 82.27 | insufficient_future_data |
| [[2026-06-03]] | Breakout Watch | 71.72 | insufficient_future_data |
| [[2026-06-04]] | Breakout Watch | 80.38 | active |
| [[2026-06-05]] | Breakout Watch | 91.0 | active |
| [[2026-06-06]] | Breakout Watch | 93.42 | active |

## Entry Plan
*Populated when entry triggered.*

## Outcome
*Populated on close. Forward-compatible: will hold fill price, order ID, broker confirmation in Phase 4-5.*

## Notes

---
[[index]]