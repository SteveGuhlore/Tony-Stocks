---
ticker: HAL
tags: [signal]
status: insufficient_future_data
first_seen: 2026-05-21
days_active: 4
---

# HAL

**Status:** entry_not_triggered
**Days Active:** 2

## Signal History
| Date | Setup | Score | Status |
|------|-------|-------|--------|
| [[2026-05-21]] | Breakout Watch | 91.26 | entry_not_triggered |
| [[2026-05-22]] | Breakout Watch | 83.43 | insufficient_future_data |
| [[2026-05-26]] | Breakout Watch | 83.43 | insufficient_future_data |
| [[2026-05-29]] | Breakout Watch | 83.43 | insufficient_future_data |
| [[2026-06-02]] | Breakout Watch | 83.43 | stop_hit |
| [[2026-06-03]] | Breakout Watch | 83.43 | stop_hit |
| [[2026-06-04]] | Breakout Watch | 82.21 | insufficient_future_data |
| [[2026-06-05]] | Breakout Watch | 78.55 | active |
| [[2026-06-06]] | Pullback Watch | 71.14 | insufficient_future_data |

## Entry Plan
*Populated when entry triggered.*

## Outcome
*Populated on close. Forward-compatible: will hold fill price, order ID, broker confirmation in Phase 4-5.*

## Notes

---
[[index]]