---
ticker: DAL
tags: [signal]
status: active
first_seen: 2026-05-21
days_active: 6
---

# DAL

**Status:** insufficient_future_data
**Days Active:** 2

## Signal History
| Date | Setup | Score | Status |
|------|-------|-------|--------|
| [[2026-05-21]] | Breakout Watch | 82.88 | insufficient_future_data |
| [[2026-05-22]] | Breakout Watch | 82.48 | insufficient_future_data |
| [[2026-05-26]] | Breakout Watch | 82.48 | insufficient_future_data |
| [[2026-05-29]] | Breakout Watch | 82.48 | insufficient_future_data |
| [[2026-06-02]] | Breakout Watch | 82.48 | partial_move |
| [[2026-06-03]] | Breakout Watch | 82.32 | insufficient_future_data |
| [[2026-06-04]] | Breakout Watch | 76.1 | active |
| [[2026-06-05]] | Breakout Watch | 73.21 | active |
| [[2026-06-06]] | Breakout Watch | 75.36 | active |

## Entry Plan
*Populated when entry triggered.*

## Outcome
*Populated on close. Forward-compatible: will hold fill price, order ID, broker confirmation in Phase 4-5.*

## Notes

---
[[index]]