---
ticker: CVS
tags: [signal]
status: active
first_seen: 2026-05-21
days_active: 7
---

# CVS

**Status:** insufficient_future_data
**Days Active:** 2

## Signal History
| Date | Setup | Score | Status |
|------|-------|-------|--------|
| [[2026-05-21]] | Breakout Watch | 92.39 | insufficient_future_data |
| [[2026-05-22]] | Breakout Watch | 91.13 | insufficient_future_data |
| [[2026-05-26]] | Breakout Watch | 91.13 | insufficient_future_data |
| [[2026-05-29]] | Breakout Watch | 91.13 | insufficient_future_data |
| [[2026-06-02]] | Pullback Watch | 66.4 | insufficient_future_data |
| [[2026-06-03]] | Pullback Watch | 66.54 | insufficient_future_data |
| [[2026-06-04]] | Breakout Watch | 78.46 | active |
| [[2026-06-05]] | Breakout Watch | 87.06 | active |
| [[2026-06-06]] | Breakout Watch | 100.0 | active |

## Entry Plan
*Populated when entry triggered.*

## Outcome
*Populated on close. Forward-compatible: will hold fill price, order ID, broker confirmation in Phase 4-5.*

## Notes

---
[[index]]