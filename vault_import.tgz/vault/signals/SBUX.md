---
ticker: SBUX
tags: [signal]
status: stop_hit
first_seen: 2026-05-21
days_active: 2
---

# SBUX

**Status:** still_open
**Days Active:** 2

## Signal History
| Date | Setup | Score | Status |
|------|-------|-------|--------|
| [[2026-05-21]] | Pullback Watch | 66.25 | still_open |
| [[2026-05-22]] | Pullback Watch | 62.04 | insufficient_future_data |
| [[2026-05-26]] | Pullback Watch | 62.04 | insufficient_future_data |
| [[2026-05-29]] | Pullback Watch | 62.04 | insufficient_future_data |
| [[2026-06-02]] | Pullback Watch | 62.04 | stop_hit |
| [[2026-06-03]] | Pullback Watch | 62.04 | stop_hit |

## Entry Plan
*Populated when entry triggered.*

## Outcome
*Populated on close. Forward-compatible: will hold fill price, order ID, broker confirmation in Phase 4-5.*

## Notes

---
[[index]]