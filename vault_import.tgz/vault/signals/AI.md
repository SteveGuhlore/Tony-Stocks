---
ticker: AI
tags: [signal]
status: active
first_seen: 2026-05-17
days_active: 3
---

# AI

**Status:** entry_not_triggered
**Days Active:** 2

## Signal History
| Date | Setup | Score | Status |
|------|-------|-------|--------|
| [[2026-05-17]] | Speculative Watchlist | 91.64 | entry_not_triggered |
| [[2026-05-18]] | Speculative Watchlist | 91.64 | entry_not_triggered |
| [[2026-05-26]] | Speculative Watchlist | 91.64 | entry_not_triggered |
| [[2026-05-29]] | Speculative Watchlist | 91.64 | entry_not_triggered |
| [[2026-06-02]] | Speculative Watchlist | 91.64 | entry_not_triggered |
| [[2026-06-03]] | Speculative Watchlist | 91.64 | entry_not_triggered |
| [[2026-06-05]] | Speculative Watchlist | 66.35 | active |
| [[2026-06-06]] | Speculative Watchlist | 66.35 | active |

## Entry Plan
*Populated when entry triggered.*

## Outcome
*Populated on close. Forward-compatible: will hold fill price, order ID, broker confirmation in Phase 4-5.*

## Notes

---
[[index]]