---
ticker: AGIO
tags: [signal]
status: entry_not_triggered
first_seen: 2026-05-18
days_active: 1
---

# AGIO

**Status:** entry_not_triggered
**Days Active:** 1

## Signal History
| Date | Setup | Score | Status |
|------|-------|-------|--------|
| [[2026-05-18]] | Speculative Watchlist | 67.0 | entry_not_triggered |
| [[2026-05-26]] | Speculative Watchlist | 67.0 | entry_not_triggered |
| [[2026-05-29]] | Speculative Watchlist | 67.0 | entry_not_triggered |
| [[2026-06-02]] | Speculative Watchlist | 67.0 | entry_not_triggered |
| [[2026-06-03]] | Speculative Watchlist | 67.0 | entry_not_triggered |

## Entry Plan
*Populated when entry triggered.*

## Outcome
*Populated on close. Forward-compatible: will hold fill price, order ID, broker confirmation in Phase 4-5.*

## Notes

---
[[index]]