---
ticker: VICI
tags: [signal]
status: stop_hit
first_seen: 2026-05-22
days_active: 1
---

# VICI

**Status:** insufficient_future_data
**Days Active:** 1

## Signal History
| Date | Setup | Score | Status |
|------|-------|-------|--------|
| [[2026-05-22]] | Breakout Watch | 74.63 | insufficient_future_data |
| [[2026-05-26]] | Breakout Watch | 74.63 | insufficient_future_data |
| [[2026-05-29]] | Breakout Watch | 74.63 | insufficient_future_data |
| [[2026-06-02]] | Breakout Watch | 74.63 | still_open |
| [[2026-06-03]] | Breakout Watch | 74.63 | stop_hit |

## Entry Plan
*Populated when entry triggered.*

## Outcome
*Populated on close. Forward-compatible: will hold fill price, order ID, broker confirmation in Phase 4-5.*

## Notes

---
[[index]]