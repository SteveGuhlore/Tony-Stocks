---
ticker: PLTR
tags: [signal]
status: insufficient_future_data
first_seen: 2026-05-17
days_active: 4
---

# PLTR

**Status:** entry_not_triggered
**Days Active:** 2

## Signal History
| Date | Setup | Score | Status |
|------|-------|-------|--------|
| [[2026-05-17]] | Breakout Watch | 100.0 | entry_not_triggered |
| [[2026-05-18]] | Breakout Watch | 100.0 | entry_not_triggered |
| [[2026-05-26]] | Breakout Watch | 100.0 | entry_not_triggered |
| [[2026-05-29]] | Breakout Watch | 100.0 | entry_not_triggered |
| [[2026-06-02]] | Breakout Watch | 100.0 | entry_not_triggered |
| [[2026-06-03]] | Momentum Continuation | 71.71 | insufficient_future_data |
| [[2026-06-04]] | Momentum Continuation | 69.99 | insufficient_future_data |
| [[2026-06-05]] | Momentum Continuation | 69.99 | insufficient_future_data |
| [[2026-06-06]] | Momentum Continuation | 69.99 | insufficient_future_data |

## Entry Plan
*Populated when entry triggered.*

## Outcome
*Populated on close. Forward-compatible: will hold fill price, order ID, broker confirmation in Phase 4-5.*

## Notes

---
[[index]]