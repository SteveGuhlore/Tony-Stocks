---
ticker: ACHR
tags: [signal]
status: entry_not_triggered
first_seen: 2026-05-22
days_active: 3
---

# ACHR

**Status:** insufficient_future_data
**Days Active:** 1

## Signal History
| Date | Setup | Score | Status |
|------|-------|-------|--------|
| [[2026-05-22]] | Speculative Watchlist | 83.46 | insufficient_future_data |
| [[2026-05-26]] | Speculative Watchlist | 83.46 | insufficient_future_data |
| [[2026-05-29]] | Speculative Watchlist | 83.46 | insufficient_future_data |
| [[2026-06-02]] | Speculative Watchlist | 83.46 | partial_move |
| [[2026-06-03]] | Speculative Watchlist | 84.6 | insufficient_future_data |
| [[2026-06-04]] | Speculative Watchlist | 88.38 | active |
| [[2026-06-05]] | Breakout Watch | 70.42 | entry_not_triggered |
| [[2026-06-06]] | Breakout Watch | 70.42 | entry_not_triggered |

## Entry Plan
*Populated when entry triggered.*

## Outcome
*Populated on close. Forward-compatible: will hold fill price, order ID, broker confirmation in Phase 4-5.*

## Notes

---
[[index]]