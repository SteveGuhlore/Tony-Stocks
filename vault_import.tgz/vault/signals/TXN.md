---
ticker: TXN
tags: [signal]
status: entry_not_triggered
first_seen: 2026-05-21
days_active: 5
---

# TXN

**Status:** insufficient_future_data
**Days Active:** 2

## Signal History
| Date | Setup | Score | Status |
|------|-------|-------|--------|
| [[2026-05-21]] | Breakout Watch | 73.22 | insufficient_future_data |
| [[2026-05-22]] | Breakout Watch | 82.97 | insufficient_future_data |
| [[2026-05-26]] | Breakout Watch | 82.97 | insufficient_future_data |
| [[2026-05-29]] | Breakout Watch | 82.97 | insufficient_future_data |
| [[2026-06-02]] | Breakout Watch | 80.26 | insufficient_future_data |
| [[2026-06-03]] | Breakout Watch | 73.92 | insufficient_future_data |
| [[2026-06-04]] | Breakout Watch | 75.22 | insufficient_future_data |
| [[2026-06-05]] | Pullback Watch | 71.05 | entry_not_triggered |
| [[2026-06-06]] | Pullback Watch | 71.05 | entry_not_triggered |

## Entry Plan
*Populated when entry triggered.*

## Outcome
*Populated on close. Forward-compatible: will hold fill price, order ID, broker confirmation in Phase 4-5.*

## Notes

---
[[index]]