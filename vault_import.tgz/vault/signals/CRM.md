---
ticker: CRM
tags: [signal]
status: insufficient_future_data
first_seen: 2026-05-18
days_active: 7
---

# CRM

**Status:** entry_not_triggered
**Days Active:** 2

## Signal History
| Date | Setup | Score | Status |
|------|-------|-------|--------|
| [[2026-05-18]] | Breakout Watch | 68.65 | entry_not_triggered |
| [[2026-05-22]] | Momentum Continuation | 62.07 | insufficient_future_data |
| [[2026-05-26]] | Momentum Continuation | 62.07 | insufficient_future_data |
| [[2026-05-29]] | Momentum Continuation | 62.07 | insufficient_future_data |
| [[2026-06-02]] | Breakout Watch | 86.88 | insufficient_future_data |
| [[2026-06-03]] | Momentum Continuation | 80.14 | insufficient_future_data |
| [[2026-06-04]] | Momentum Continuation | 80.95 | insufficient_future_data |
| [[2026-06-05]] | Momentum Continuation | 75.43 | insufficient_future_data |
| [[2026-06-06]] | Pullback Watch | 77.22 | insufficient_future_data |

## Entry Plan
*Populated when entry triggered.*

## Outcome
*Populated on close. Forward-compatible: will hold fill price, order ID, broker confirmation in Phase 4-5.*

## Notes

---
[[index]]