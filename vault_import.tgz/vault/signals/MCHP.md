---
ticker: MCHP
tags: [signal]
status: entry_not_triggered
first_seen: 2026-06-05
days_active: 1
---

# MCHP

**Status:** entry_not_triggered
**Days Active:** 1

## Signal History
| Date | Setup | Score | Status |
|------|-------|-------|--------|
| [[2026-06-05]] | Breakout Watch | 75.95 | entry_not_triggered |
| [[2026-06-06]] | Breakout Watch | 75.95 | entry_not_triggered |

## Entry Plan
*Populated when entry triggered.*

## Outcome
*Populated on close. Forward-compatible: will hold fill price, order ID, broker confirmation in Phase 4-5.*

## Notes

---
[[index]]