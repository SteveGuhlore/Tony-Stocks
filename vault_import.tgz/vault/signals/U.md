---
ticker: U
tags: [signal]
status: insufficient_future_data
first_seen: 2026-05-17
days_active: 7
---

# U

**Status:** entry_not_triggered
**Days Active:** 3

## Signal History
| Date | Setup | Score | Status |
|------|-------|-------|--------|
| [[2026-05-17]] | Speculative Watchlist | 71.27 | entry_not_triggered |
| [[2026-05-18]] | Breakout Watch | 69.62 | partial_move |
| [[2026-05-19]] | Speculative Watchlist | 74.26 | entry_not_triggered |
| [[2026-05-26]] | Speculative Watchlist | 74.26 | entry_not_triggered |
| [[2026-05-29]] | Speculative Watchlist | 74.26 | entry_not_triggered |
| [[2026-06-02]] | Speculative Watchlist | 74.26 | partial_move |
| [[2026-06-03]] | Speculative Watchlist | 74.98 | insufficient_future_data |
| [[2026-06-04]] | Speculative Watchlist | 73.28 | insufficient_future_data |
| [[2026-06-05]] | Speculative Watchlist | 74.94 | active |
| [[2026-06-06]] | Speculative Watchlist | 79.76 | insufficient_future_data |

## Entry Plan
*Populated when entry triggered.*

## Outcome
*Populated on close. Forward-compatible: will hold fill price, order ID, broker confirmation in Phase 4-5.*

## Notes

---
[[index]]