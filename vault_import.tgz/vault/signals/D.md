---
ticker: D
tags: [signal]
status: active
first_seen: 2026-05-21
days_active: 7
---

# D

**Status:** insufficient_future_data
**Days Active:** 2

## Signal History
| Date | Setup | Score | Status |
|------|-------|-------|--------|
| [[2026-05-21]] | Breakout Watch | 85.63 | insufficient_future_data |
| [[2026-05-22]] | Breakout Watch | 85.24 | insufficient_future_data |
| [[2026-05-26]] | Breakout Watch | 85.24 | insufficient_future_data |
| [[2026-05-29]] | Breakout Watch | 85.24 | insufficient_future_data |
| [[2026-06-02]] | Breakout Watch | 90.35 | insufficient_future_data |
| [[2026-06-03]] | Breakout Watch | 79.37 | insufficient_future_data |
| [[2026-06-04]] | Breakout Watch | 81.6 | active |
| [[2026-06-05]] | Breakout Watch | 83.95 | active |
| [[2026-06-06]] | Breakout Watch | 86.03 | active |

## Entry Plan
*Populated when entry triggered.*

## Outcome
*Populated on close. Forward-compatible: will hold fill price, order ID, broker confirmation in Phase 4-5.*

## Notes

---
[[index]]