---
ticker: LYFT
tags: [signal]
status: active
first_seen: 2026-05-18
days_active: 6
---

# LYFT

**Status:** entry_not_triggered
**Days Active:** 2

## Signal History
| Date | Setup | Score | Status |
|------|-------|-------|--------|
| [[2026-05-18]] | Breakout Watch | 99.51 | entry_not_triggered |
| [[2026-05-22]] | Breakout Watch | 75.78 | insufficient_future_data |
| [[2026-05-26]] | Breakout Watch | 75.78 | insufficient_future_data |
| [[2026-05-29]] | Breakout Watch | 75.78 | insufficient_future_data |
| [[2026-06-02]] | Breakout Watch | 73.13 | insufficient_future_data |
| [[2026-06-03]] | Breakout Watch | 63.7 | insufficient_future_data |
| [[2026-06-04]] | Breakout Watch | 71.05 | active |
| [[2026-06-05]] | Breakout Watch | 67.99 | active |
| [[2026-06-06]] | Breakout Watch | 67.99 | active |

## Entry Plan
*Populated when entry triggered.*

## Outcome
*Populated on close. Forward-compatible: will hold fill price, order ID, broker confirmation in Phase 4-5.*

## Notes

---
[[index]]