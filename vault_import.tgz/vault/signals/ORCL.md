---
ticker: ORCL
tags: [signal]
status: target_hit
first_seen: 2026-05-21
days_active: 2
---

# ORCL

**Status:** insufficient_future_data
**Days Active:** 2

## Signal History
| Date | Setup | Score | Status |
|------|-------|-------|--------|
| [[2026-05-21]] | Breakout Watch | 71.95 | insufficient_future_data |
| [[2026-05-22]] | Breakout Watch | 76.11 | insufficient_future_data |
| [[2026-05-26]] | Breakout Watch | 76.11 | insufficient_future_data |
| [[2026-05-29]] | Breakout Watch | 76.11 | insufficient_future_data |
| [[2026-06-02]] | Breakout Watch | 76.11 | target_hit |
| [[2026-06-03]] | Breakout Watch | 76.11 | target_hit |

## Entry Plan
*Populated when entry triggered.*

## Outcome
*Populated on close. Forward-compatible: will hold fill price, order ID, broker confirmation in Phase 4-5.*

## Notes

---
[[index]]