---
ticker: DOC
tags: [signal]
status: active
first_seen: 2026-06-05
days_active: 2
---

# DOC

**Status:** active
**Days Active:** 1

## Signal History
| Date | Setup | Score | Status |
|------|-------|-------|--------|
| [[2026-06-05]] | Breakout Watch | 74.28 | active |
| [[2026-06-06]] | Breakout Watch | 74.52 | active |

## Entry Plan
*Populated when entry triggered.*

## Outcome
*Populated on close. Forward-compatible: will hold fill price, order ID, broker confirmation in Phase 4-5.*

## Notes

---
[[index]]