---
ticker: WBD
tags: [signal]
status: still_open
first_seen: 2026-05-21
days_active: 1
---

# WBD

**Status:** entry_not_triggered
**Days Active:** 1

## Signal History
| Date | Setup | Score | Status |
|------|-------|-------|--------|
| [[2026-05-21]] | Breakout Watch | 69.41 | entry_not_triggered |
| [[2026-05-26]] | Breakout Watch | 69.41 | entry_not_triggered |
| [[2026-05-29]] | Breakout Watch | 69.41 | entry_not_triggered |
| [[2026-06-02]] | Breakout Watch | 69.41 | still_open |
| [[2026-06-03]] | Breakout Watch | 69.41 | still_open |

## Entry Plan
*Populated when entry triggered.*

## Outcome
*Populated on close. Forward-compatible: will hold fill price, order ID, broker confirmation in Phase 4-5.*

## Notes

---
[[index]]