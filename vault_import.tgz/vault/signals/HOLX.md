---
ticker: HOLX
tags: [signal]
status: insufficient_future_data
first_seen: 2026-06-05
days_active: 3
---

# HOLX

**Status:** insufficient_future_data
**Days Active:** 2

## Signal History
| Date | Setup | Score | Status |
|------|-------|-------|--------|
| [[2026-06-05]] | Breakout Watch | 79.84 | insufficient_future_data |
| [[2026-06-06]] | Breakout Watch | 80.91 | insufficient_future_data |

## Entry Plan
*Populated when entry triggered.*

## Outcome
*Populated on close. Forward-compatible: will hold fill price, order ID, broker confirmation in Phase 4-5.*

## Notes

---
[[index]]