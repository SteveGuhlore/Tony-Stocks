---
ticker: SLB
tags: [signal]
status: insufficient_future_data
first_seen: 2026-05-21
days_active: 6
---

# SLB

**Status:** insufficient_future_data
**Days Active:** 2

## Signal History
| Date | Setup | Score | Status |
|------|-------|-------|--------|
| [[2026-05-21]] | Breakout Watch | 93.43 | insufficient_future_data |
| [[2026-05-22]] | Breakout Watch | 91.48 | insufficient_future_data |
| [[2026-05-26]] | Breakout Watch | 91.48 | insufficient_future_data |
| [[2026-05-29]] | Breakout Watch | 91.48 | insufficient_future_data |
| [[2026-06-02]] | Breakout Watch | 91.48 | stop_hit |
| [[2026-06-03]] | Breakout Watch | 91.48 | stop_hit |
| [[2026-06-04]] | Breakout Watch | 85.03 | active |
| [[2026-06-05]] | Breakout Watch | 91.49 | active |
| [[2026-06-06]] | Breakout Watch | 74.97 | insufficient_future_data |

## Entry Plan
*Populated when entry triggered.*

## Outcome
*Populated on close. Forward-compatible: will hold fill price, order ID, broker confirmation in Phase 4-5.*

## Notes

---
[[index]]