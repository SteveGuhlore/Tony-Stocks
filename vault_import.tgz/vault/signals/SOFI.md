---
ticker: SOFI
tags: [signal]
status: entry_not_triggered
first_seen: 2026-05-17
days_active: 4
---

# SOFI

**Status:** entry_not_triggered
**Days Active:** 2

## Signal History
| Date | Setup | Score | Status |
|------|-------|-------|--------|
| [[2026-05-17]] | Speculative Watchlist | 92.38 | entry_not_triggered |
| [[2026-05-18]] | Speculative Watchlist | 92.38 | entry_not_triggered |
| [[2026-05-26]] | Speculative Watchlist | 92.38 | entry_not_triggered |
| [[2026-05-29]] | Speculative Watchlist | 92.38 | entry_not_triggered |
| [[2026-06-02]] | Speculative Watchlist | 92.38 | entry_not_triggered |
| [[2026-06-03]] | Speculative Watchlist | 68.56 | insufficient_future_data |
| [[2026-06-04]] | Speculative Watchlist | 68.17 | active |
| [[2026-06-05]] | Speculative Watchlist | 62.81 | entry_not_triggered |
| [[2026-06-06]] | Speculative Watchlist | 62.81 | entry_not_triggered |

## Entry Plan
*Populated when entry triggered.*

## Outcome
*Populated on close. Forward-compatible: will hold fill price, order ID, broker confirmation in Phase 4-5.*

## Notes

---
[[index]]