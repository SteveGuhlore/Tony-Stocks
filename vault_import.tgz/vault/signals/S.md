---
ticker: S
tags: [signal]
status: entry_not_triggered
first_seen: 2026-05-18
days_active: 3
---

# S

**Status:** entry_not_triggered
**Days Active:** 1

## Signal History
| Date | Setup | Score | Status |
|------|-------|-------|--------|
| [[2026-05-18]] | Breakout Watch | 87.08 | entry_not_triggered |
| [[2026-05-26]] | Breakout Watch | 87.08 | entry_not_triggered |
| [[2026-05-29]] | Breakout Watch | 87.08 | entry_not_triggered |
| [[2026-06-02]] | Pullback Watch | 76.97 | insufficient_future_data |
| [[2026-06-03]] | Pullback Watch | 74.09 | entry_not_triggered |
| [[2026-06-04]] | Pullback Watch | 74.09 | entry_not_triggered |
| [[2026-06-05]] | Pullback Watch | 74.09 | entry_not_triggered |
| [[2026-06-06]] | Pullback Watch | 74.09 | entry_not_triggered |

## Entry Plan
*Populated when entry triggered.*

## Outcome
*Populated on close. Forward-compatible: will hold fill price, order ID, broker confirmation in Phase 4-5.*

## Notes

---
[[index]]