---
ticker: CARR
tags: [signal]
status: active
first_seen: 2026-06-05
days_active: 3
---

# CARR

**Status:** active
**Days Active:** 2

## Signal History
| Date | Setup | Score | Status |
|------|-------|-------|--------|
| [[2026-06-05]] | Breakout Watch | 76.6 | active |
| [[2026-06-06]] | Breakout Watch | 89.58 | active |

## Entry Plan
*Populated when entry triggered.*

## Outcome
*Populated on close. Forward-compatible: will hold fill price, order ID, broker confirmation in Phase 4-5.*

## Notes

---
[[index]]