---
ticker: VRTX
tags: [signal]
status: target_hit
first_seen: 2026-05-18
days_active: 1
---

# VRTX

**Status:** target_hit
**Days Active:** 1

## Signal History
| Date | Setup | Score | Status |
|------|-------|-------|--------|
| [[2026-05-18]] | Breakout Watch | 97.61 | target_hit |
| [[2026-05-26]] | Breakout Watch | 97.61 | target_hit |
| [[2026-05-29]] | Breakout Watch | 97.61 | target_hit |
| [[2026-06-02]] | Breakout Watch | 97.61 | target_hit |
| [[2026-06-03]] | Breakout Watch | 97.61 | target_hit |

## Entry Plan
*Populated when entry triggered.*

## Outcome
*Populated on close. Forward-compatible: will hold fill price, order ID, broker confirmation in Phase 4-5.*

## Notes

---
[[index]]