---
ticker: DHR
tags: [signal]
status: active
first_seen: 2026-06-02
days_active: 4
---

# DHR

**Status:** insufficient_future_data
**Days Active:** 1

## Signal History
| Date | Setup | Score | Status |
|------|-------|-------|--------|
| [[2026-06-02]] | Momentum Continuation | 70.24 | insufficient_future_data |
| [[2026-06-03]] | Momentum Continuation | 70.24 | entry_not_triggered |
| [[2026-06-05]] | Momentum Continuation | 70.19 | active |
| [[2026-06-06]] | Momentum Continuation | 64.78 | active |

## Entry Plan
*Populated when entry triggered.*

## Outcome
*Populated on close. Forward-compatible: will hold fill price, order ID, broker confirmation in Phase 4-5.*

## Notes

---
[[index]]