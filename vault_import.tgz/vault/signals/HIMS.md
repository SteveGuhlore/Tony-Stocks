---
ticker: HIMS
tags: [signal]
status: active
first_seen: 2026-05-17
days_active: 6
---

# HIMS

**Status:** entry_not_triggered
**Days Active:** 2

## Signal History
| Date | Setup | Score | Status |
|------|-------|-------|--------|
| [[2026-05-17]] | Breakout Watch | 100.0 | entry_not_triggered |
| [[2026-05-18]] | Breakout Watch | 100.0 | entry_not_triggered |
| [[2026-05-26]] | Breakout Watch | 100.0 | entry_not_triggered |
| [[2026-05-29]] | Breakout Watch | 100.0 | entry_not_triggered |
| [[2026-06-02]] | Breakout Watch | 100.0 | entry_not_triggered |
| [[2026-06-03]] | Momentum Continuation | 71.78 | insufficient_future_data |
| [[2026-06-04]] | Momentum Continuation | 78.59 | active |
| [[2026-06-05]] | Momentum Continuation | 78.59 | active |
| [[2026-06-06]] | Pullback Watch | 82.96 | active |

## Entry Plan
*Populated when entry triggered.*

## Outcome
*Populated on close. Forward-compatible: will hold fill price, order ID, broker confirmation in Phase 4-5.*

## Notes

---
[[index]]