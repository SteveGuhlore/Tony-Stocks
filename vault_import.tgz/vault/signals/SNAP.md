---
ticker: SNAP
tags: [signal]
status: insufficient_future_data
first_seen: 2026-05-18
days_active: 4
---

# SNAP

**Status:** entry_not_triggered
**Days Active:** 2

## Signal History
| Date | Setup | Score | Status |
|------|-------|-------|--------|
| [[2026-05-18]] | Speculative Watchlist | 78.76 | entry_not_triggered |
| [[2026-05-21]] | Speculative Watchlist | 64.98 | partial_move |
| [[2026-05-26]] | Speculative Watchlist | 64.98 | partial_move |
| [[2026-05-29]] | Speculative Watchlist | 64.98 | partial_move |
| [[2026-06-02]] | Speculative Watchlist | 64.98 | partial_move |
| [[2026-06-03]] | Speculative Watchlist | 64.98 | partial_move |
| [[2026-06-05]] | Speculative Watchlist | 84.08 | insufficient_future_data |
| [[2026-06-06]] | Breakout Watch | 64.83 | insufficient_future_data |

## Entry Plan
*Populated when entry triggered.*

## Outcome
*Populated on close. Forward-compatible: will hold fill price, order ID, broker confirmation in Phase 4-5.*

## Notes

---
[[index]]