---
as_of: 2026-06-07
type: learning-knowledge
research_only: true
---

# What the bot has learned

- ✅ **Technology sector** — confirmed, 89% win (n=9, low, trend flat) · since 2026-06-04
- 🌱 **Consumer Discretionary sector** — emerging, 0% win (n=1, insufficient, trend flat) · since 2026-06-06
- 🌱 **Consumer Staples sector** — emerging, 50% win (n=4, insufficient, trend up) · since 2026-06-04
- 🌱 **Financials sector** — emerging, 100% win (n=2, insufficient, trend flat) · since 2026-06-04
- 🌱 **Healthcare sector** — emerging, 50% win (n=2, insufficient, trend up) · since 2026-06-04
- 🌱 **Industrials sector** — emerging, 100% win (n=1, insufficient, trend flat) · since 2026-06-04
- 🌱 **Materials sector** — emerging, 100% win (n=1, insufficient, trend flat) · since 2026-06-04
- 🌱 **Utilities sector** — emerging, 0% win (n=2, insufficient, trend flat) · since 2026-06-04
- ❌ **Communication Services sector** — rejected, 33% win (n=6, low, trend flat) · since 2026-06-04
- ❌ **Energy sector** — rejected, 0% win (n=5, low, trend flat) · since 2026-06-04
