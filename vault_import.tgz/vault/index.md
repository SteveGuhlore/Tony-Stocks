# Trading Bot Vault — Index

*Last updated: 2026-06-06*

## Latest Daily Note
[[daily/2026-06-06]]

## Current Active Positions
| Ticker | Score | Status |
|--------|-------|--------|
| [[signals/CVS]] | 100.0 | active |
| [[signals/CSX]] | 97.05 | active |
| [[signals/KDP]] | 95.77 | active |
| [[signals/PINS]] | 93.42 | active |
| [[signals/FITB]] | 91.59 | active |
| [[signals/CARR]] | 89.58 | active |
| [[signals/RF]] | 87.12 | active |
| [[signals/MNST]] | 86.32 | active |
| [[signals/ANET]] | 86.05 | active |
| [[signals/D]] | 86.03 | active |
| [[signals/BAX]] | 85.76 | active |
| [[signals/C]] | 84.71 | active |
| [[signals/MDT]] | 84.17 | active |
| [[signals/MS]] | 84.12 | active |
| [[signals/INVH]] | 83.28 | active |
| [[signals/HIMS]] | 82.96 | active |
| [[signals/KO]] | 82.17 | active |
| [[signals/DXCM]] | 82.16 | active |
| [[signals/DBX]] | 82.13 | active |
| [[signals/NOV]] | 80.91 | active |
| [[signals/FAST]] | 80.76 | active |
| [[signals/MRK]] | 78.38 | active |
| [[signals/WFC]] | 78.01 | active |
| [[signals/DKNG]] | 77.72 | active |
| [[signals/HOOD]] | 77.34 | active |
| [[signals/USB]] | 76.38 | active |
| [[signals/GM]] | 75.52 | active |
| [[signals/DAL]] | 75.36 | active |
| [[signals/BAC]] | 75.09 | active |
| [[signals/TFC]] | 74.79 | active |
| [[signals/DOC]] | 74.52 | active |
| [[signals/FLEX]] | 73.62 | active |
| [[signals/PATH]] | 73.42 | active |
| [[signals/HBAN]] | 73.22 | active |
| [[signals/CCL]] | 69.51 | active |
| [[signals/LYFT]] | 67.99 | active |
| [[signals/AI]] | 66.35 | active |
| [[signals/APH]] | 65.84 | active |
| [[signals/DHR]] | 64.78 | active |
| [[signals/GLW]] | 63.63 | active |

## All Daily Notes
[[daily/2026-05-17]] | [[daily/2026-05-18]] | [[daily/2026-05-19]] | [[daily/2026-05-20]] | [[daily/2026-05-21]] | [[daily/2026-05-22]] | [[daily/2026-05-26]] | [[daily/2026-05-29]] | [[daily/2026-06-02]] | [[daily/2026-06-03]] | [[daily/2026-06-04]] | [[daily/2026-06-05]] | [[daily/2026-06-06]]

## Navigation
- [[signals/]] — all ticker pages
- [[outcomes/]] — performance ledger
- [[strategy/]] — strategy versions and proposals
- [[memory/agent-context]] — curated vault summary